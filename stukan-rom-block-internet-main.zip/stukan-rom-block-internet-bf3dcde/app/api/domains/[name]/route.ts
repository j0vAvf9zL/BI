import { NextRequest, NextResponse } from "next/server";
import { ConditionalCheckFailedException } from "@aws-sdk/client-dynamodb";
import { isDatabaseAvailable } from "@/lib/db";
import { deleteDomain, getDomainByName } from "@/lib/models";
import { mockDomains } from "@/lib/mock-data";
import { deleteDomainQuerySchema, domainNameSchema } from "@/lib/validation";

interface RouteContext {
  params: Promise<{ name: string }>;
}

export async function GET(_request: NextRequest, context: RouteContext) {
  const { name } = await context.params;
  const parsed = domainNameSchema.safeParse(name);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректное имя домена" },
      { status: 400 }
    );
  }

  const domainName = parsed.data;

  if (!(await isDatabaseAvailable())) {
    const mock = mockDomains.find((domain) => domain.name === domainName);
    if (!mock) {
      return NextResponse.json({ error: "Домен не найден" }, { status: 404 });
    }
    return NextResponse.json(mock);
  }

  try {
    const domain = await getDomainByName(domainName);
    if (!domain) {
      return NextResponse.json({ error: "Домен не найден" }, { status: 404 });
    }
    return NextResponse.json(domain);
  } catch (error) {
    console.error("Ошибка получения домена:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  const { name } = await context.params;
  const parsedName = domainNameSchema.safeParse(name);

  if (!parsedName.success) {
    return NextResponse.json(
      { error: "Некорректное имя домена" },
      { status: 400 }
    );
  }

  const { searchParams } = new URL(request.url);
  const parsedOwner = deleteDomainQuerySchema.safeParse({
    owner: searchParams.get("owner") ?? "",
  });

  if (!parsedOwner.success) {
    return NextResponse.json(
      { error: "Параметр owner обязателен и должен быть корректным адресом" },
      { status: 400 }
    );
  }

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "Удаление доменов недоступно: база данных не подключена" },
      { status: 503 }
    );
  }

  try {
    await deleteDomain(parsedName.data, parsedOwner.data.owner);
    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof ConditionalCheckFailedException) {
      return NextResponse.json(
        { error: "Домен не принадлежит этому аккаунту" },
        { status: 403 }
      );
    }
    console.error("Ошибка удаления домена:", error);
    return NextResponse.json(
      { error: "Не удалось удалить домен" },
      { status: 500 }
    );
  }
}
