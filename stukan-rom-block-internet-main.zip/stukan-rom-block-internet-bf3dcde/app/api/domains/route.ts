import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  DomainTakenError,
  getDomainsByOwner,
  registerDomain,
} from "@/lib/models";
import { mockDomains } from "@/lib/mock-data";
import { ownerQuerySchema, registerDomainSchema } from "@/lib/validation";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const parsed = ownerQuerySchema.safeParse({
    owner: searchParams.get("owner") ?? "",
  });

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Параметр owner обязателен и должен быть корректным адресом" },
      { status: 400 }
    );
  }

  const { owner } = parsed.data;

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      mockDomains.filter((domain) => domain.ownerAddress === owner)
    );
  }

  try {
    const domains = await getDomainsByOwner(owner);
    return NextResponse.json(domains);
  } catch (error) {
    console.error("Ошибка получения доменов:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const parsed = registerDomainSchema.safeParse(await request.json());

  if (!parsed.success) {
    return NextResponse.json(
      {
        error: parsed.error.issues[0]?.message ?? "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "Регистрация доменов недоступна: база данных не подключена" },
      { status: 503 }
    );
  }

  const { name, owner } = parsed.data;

  try {
    const domain = await registerDomain(name, owner);
    return NextResponse.json(domain, { status: 201 });
  } catch (error) {
    if (error instanceof DomainTakenError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    console.error("Ошибка регистрации домена:", error);
    return NextResponse.json(
      { error: "Не удалось зарегистрировать домен" },
      { status: 500 }
    );
  }
}
