import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getFileById } from "@/lib/models";
import { mockFiles } from "@/lib/mock-data";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!id.trim()) {
    return NextResponse.json({ error: "id обязателен" }, { status: 400 });
  }

  let file: Awaited<ReturnType<typeof getFileById>> | null = null;

  if (await isDatabaseAvailable()) {
    try {
      file = await getFileById(id);
    } catch (error) {
      console.error("Ошибка получения файла:", error);
      return NextResponse.json(
        { error: "Ошибка получения данных из DynamoDB" },
        { status: 500 }
      );
    }
  } else {
    file = mockFiles.find((mock) => mock.id === id) ?? null;
  }

  if (!file) {
    return NextResponse.json({ error: "Файл не найден" }, { status: 404 });
  }

  const encodedName = encodeURIComponent(file.name);

  return new NextResponse(new Uint8Array(file.data), {
    headers: {
      "Content-Type": file.contentType,
      "Content-Length": String(file.size),
      "Content-Disposition": `attachment; filename*=UTF-8''${encodedName}`,
      "Cache-Control": "no-store",
    },
  });
}
