import { NextRequest, NextResponse } from "next/server";
import { ConditionalCheckFailedException } from "@aws-sdk/client-dynamodb";
import { isDatabaseAvailable } from "@/lib/db";
import { deleteFile } from "@/lib/models";
import { ownerQuerySchema } from "@/lib/validation";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!id.trim()) {
    return NextResponse.json({ error: "id обязателен" }, { status: 400 });
  }

  const { searchParams } = new URL(request.url);
  const parsedOwner = ownerQuerySchema.safeParse({
    owner: searchParams.get("owner") ?? "",
  });

  if (!parsedOwner.success) {
    return NextResponse.json(
      { error: "Параметр owner обязателен и должен быть корректным адресом" },
      { status: 400 }
    );
  }

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "Удаление файлов недоступно: база данных не подключена" },
      { status: 503 }
    );
  }

  try {
    await deleteFile(id, parsedOwner.data.owner);
    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof ConditionalCheckFailedException) {
      return NextResponse.json(
        { error: "Файл не найден или не принадлежит этому аккаунту" },
        { status: 403 }
      );
    }
    console.error("Ошибка удаления файла:", error);
    return NextResponse.json(
      { error: "Не удалось удалить файл" },
      { status: 500 }
    );
  }
}
