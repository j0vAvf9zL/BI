import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getFilesByOwner, saveFile, toFileInfo } from "@/lib/models";
import { mockFiles } from "@/lib/mock-data";
import { ownerQuerySchema, uploadFileSchema } from "@/lib/validation";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const parsed = ownerQuerySchema.safeParse({
    owner: searchParams.get("owner") ?? "",
  });

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Параметр owner обязателен и должен быть корректным адресом" },
      { status: 400 }
    );
  }

  const { owner } = parsed.data;

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      mockFiles.filter((file) => file.ownerAddress === owner).map(toFileInfo)
    );
  }

  try {
    const files = await getFilesByOwner(owner);
    return NextResponse.json(files.map(toFileInfo));
  } catch (error) {
    console.error("Ошибка получения файлов:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "Загрузка файлов недоступна: база данных не подключена" },
      { status: 503 }
    );
  }

  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return NextResponse.json(
      { error: "Некорректные данные формы" },
      { status: 400 }
    );
  }

  const parsed = uploadFileSchema.safeParse({
    owner: String(formData.get("owner") ?? ""),
    file: formData.get("file"),
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        error: parsed.error.issues[0]?.message ?? "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  const { owner, file } = parsed.data;

  try {
    const data = new Uint8Array(await file.arrayBuffer());
    const stored = await saveFile({
      id: crypto.randomUUID(),
      ownerAddress: owner,
      name: file.name || "file",
      size: file.size,
      contentType: file.type || "application/octet-stream",
      data,
    });
    return NextResponse.json(toFileInfo(stored), { status: 201 });
  } catch (error) {
    console.error("Ошибка сохранения файла:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить файл" },
      { status: 500 }
    );
  }
}
