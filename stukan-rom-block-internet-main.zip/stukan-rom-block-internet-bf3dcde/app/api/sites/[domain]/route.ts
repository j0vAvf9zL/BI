import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getSiteByDomain } from "@/lib/models";
import { mockSites } from "@/lib/mock-data";
import { domainNameSchema } from "@/lib/validation";

interface RouteContext {
  params: Promise<{ domain: string }>;
}

export async function GET(_request: NextRequest, context: RouteContext) {
  const { domain } = await context.params;
  const parsed = domainNameSchema.safeParse(domain);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректный домен сайта" },
      { status: 400 }
    );
  }

  const domainName = parsed.data;

  if (!(await isDatabaseAvailable())) {
    const mock = mockSites.find((site) => site.domain === domainName);
    if (!mock) {
      return NextResponse.json({ error: "Сайт не найден" }, { status: 404 });
    }
    return NextResponse.json(mock);
  }

  try {
    const site = await getSiteByDomain(domainName);
    if (!site) {
      return NextResponse.json({ error: "Сайт не найден" }, { status: 404 });
    }
    return NextResponse.json(site);
  } catch (error) {
    console.error("Ошибка получения сайта:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}
