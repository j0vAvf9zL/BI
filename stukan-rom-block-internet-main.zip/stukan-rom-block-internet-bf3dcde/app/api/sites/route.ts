import { NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAllSites } from "@/lib/models";
import { mockSites } from "@/lib/mock-data";

export async function GET() {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(mockSites);
  }

  try {
    const sites = await getAllSites();
    return NextResponse.json(sites);
  } catch (error) {
    console.error("Ошибка получения сайтов:", error);
    return NextResponse.json(
      { error: "Ошибка получения данных из DynamoDB" },
      { status: 500 }
    );
  }
}
