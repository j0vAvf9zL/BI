import Link from "next/link";
import { ArrowLeft, Compass } from "lucide-react";
import { buttonVariants } from "@/components/ui/button-variants";

export default function SiteNotFound() {
  return (
    <div className="container mx-auto px-4 py-24">
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <Compass className="h-8 w-8 text-muted-foreground" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Сайт не найден</h1>
        <p className="text-muted-foreground">
          Такого сайта нет в каталоге — возможно, он ещё не опубликован или уже
          удалён из сети.
        </p>
        <Link href="/catalog" className={buttonVariants({ size: "lg" })}>
          <ArrowLeft className="mr-2 h-4 w-4" />К каталогу сайтов
        </Link>
      </div>
    </div>
  );
}
