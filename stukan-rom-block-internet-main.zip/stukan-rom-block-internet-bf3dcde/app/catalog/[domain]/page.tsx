import { notFound } from "next/navigation";
import { SiteDetail } from "@/components/site-detail";
import { isDatabaseAvailable } from "@/lib/db";
import { getSiteByDomain, type Site } from "@/lib/models";
import { mockSites } from "@/lib/mock-data";
import { domainNameSchema } from "@/lib/validation";

interface SitePageProps {
  params: Promise<{ domain: string }>;
}

export default async function SitePage({ params }: SitePageProps) {
  const { domain } = await params;
  const parsed = domainNameSchema.safeParse(domain);

  if (!parsed.success) {
    notFound();
  }

  const domainName = parsed.data;

  let site: Site | null = null;

  if (await isDatabaseAvailable()) {
    try {
      site = await getSiteByDomain(domainName);
    } catch (error) {
      console.error("Ошибка получения сайта:", error);
      notFound();
    }
  } else {
    site = mockSites.find((mock) => mock.domain === domainName) ?? null;
  }

  if (!site) {
    notFound();
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h1 className="text-3xl font-bold tracking-tight">Страница сайта</h1>
        <p className="mt-2 text-muted-foreground">
          Подробная информация о сайте в децентрализованной сети.
        </p>
      </div>
      <SiteDetail site={site} />
    </div>
  );
}
