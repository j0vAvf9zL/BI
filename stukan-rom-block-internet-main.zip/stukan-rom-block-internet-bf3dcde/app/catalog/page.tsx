import { SiteCatalog } from "@/components/site-catalog";
import { isDatabaseAvailable } from "@/lib/db";
import { getAllSites, type Site } from "@/lib/models";
import { mockSites } from "@/lib/mock-data";

export const dynamic = "force-dynamic";

export default async function CatalogPage() {
  let sites: Site[] = [];

  if (await isDatabaseAvailable()) {
    try {
      sites = await getAllSites();
    } catch (error) {
      console.error("Ошибка получения сайтов:", error);
      sites = mockSites;
    }
  } else {
    sites = mockSites;
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h1 className="text-3xl font-bold tracking-tight">
          Каталог децентрализованных сайтов
        </h1>
        <p className="mt-2 text-muted-foreground">
          Сайты и сервисы, доступные по адресам вида «имя.crypto». Поиск — по
          названию или домену.
        </p>
      </div>
      <SiteCatalog sites={sites} />
    </div>
  );
}
