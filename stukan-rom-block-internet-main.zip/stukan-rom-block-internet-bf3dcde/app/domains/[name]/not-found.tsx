import Link from "next/link";
import { ArrowLeft, Globe } from "lucide-react";
import { buttonVariants } from "@/components/ui/button-variants";

export default function DomainNotFound() {
  return (
    <div className="container mx-auto px-4 py-24">
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <Globe className="h-8 w-8 text-muted-foreground" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Домен не найден</h1>
        <p className="text-muted-foreground">
          Такого домена нет в сети — возможно, он ещё не зарегистрирован или уже
          удалён.
        </p>
        <Link href="/domains" className={buttonVariants({ size: "lg" })}>
          <ArrowLeft className="mr-2 h-4 w-4" />К списку доменов
        </Link>
      </div>
    </div>
  );
}
