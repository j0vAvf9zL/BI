import { notFound } from "next/navigation";
import { DomainDetail } from "@/components/domain-detail";
import { isDatabaseAvailable } from "@/lib/db";
import { getDomainByName, type Domain } from "@/lib/models";
import { mockDomains } from "@/lib/mock-data";
import { domainNameSchema } from "@/lib/validation";

interface DomainPageProps {
  params: Promise<{ name: string }>;
}

export default async function DomainPage({ params }: DomainPageProps) {
  const { name } = await params;
  const parsed = domainNameSchema.safeParse(name);

  if (!parsed.success) {
    notFound();
  }

  const domainName = parsed.data;

  let domain: Domain | null = null;

  if (await isDatabaseAvailable()) {
    try {
      domain = await getDomainByName(domainName);
    } catch (error) {
      console.error("Ошибка получения домена:", error);
      notFound();
    }
  } else {
    domain = mockDomains.find((mock) => mock.name === domainName) ?? null;
  }

  if (!domain) {
    notFound();
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h1 className="text-3xl font-bold tracking-tight">Страница домена</h1>
        <p className="mt-2 text-muted-foreground">
          Информация о децентрализованном домене и управление им.
        </p>
      </div>
      <DomainDetail domain={domain} />
    </div>
  );
}
