import { DomainsManager } from "@/components/domains-manager";

export default function DomainsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h1 className="text-3xl font-bold tracking-tight">Домены</h1>
        <p className="mt-2 text-muted-foreground">
          Регистрируйте свободные адреса вида «имя.crypto» и управляйте своими
          доменами.
        </p>
      </div>
      <DomainsManager />
    </div>
  );
}
