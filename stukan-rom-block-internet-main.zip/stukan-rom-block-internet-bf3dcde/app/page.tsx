import Link from "next/link";
import {
  ArrowRight,
  Compass,
  Globe,
  HardDrive,
  KeyRound,
  ShieldCheck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button-variants";

const sections = [
  {
    href: "/domains",
    icon: Globe,
    accent: "text-sky-400",
    iconBg: "bg-sky-400/10 ring-sky-400/20",
    hoverBorder: "hover:border-sky-400/30",
    title: "Домены",
    description:
      "Регистрируйте адреса вида «имя.crypto» — без централизованных регистраторов.",
  },
  {
    href: "/catalog",
    icon: Compass,
    accent: "text-violet-400",
    iconBg: "bg-violet-400/10 ring-violet-400/20",
    hoverBorder: "hover:border-violet-400/30",
    title: "Каталог",
    description:
      "Находите сайты и сервисы, доступные по децентрализованным адресам.",
  },
  {
    href: "/profile",
    icon: KeyRound,
    accent: "text-emerald-400",
    iconBg: "bg-emerald-400/10 ring-emerald-400/20",
    hoverBorder: "hover:border-emerald-400/30",
    title: "Профиль",
    description:
      "Вход по публичному ключу — без пароля и email. Все домены в одном месте.",
  },
  {
    href: "/storage",
    icon: HardDrive,
    accent: "text-amber-400",
    iconBg: "bg-amber-400/10 ring-amber-400/20",
    hoverBorder: "hover:border-amber-400/30",
    title: "Хранилище",
    description:
      "Загружайте файлы в децентрализованное хранилище и делитесь ссылками.",
  },
];

const stats = [
  { value: "1,2 млн", label: "доменов в сети" },
  { value: "8 400+", label: "сайтов в каталоге" },
  { value: "300 ТБ", label: "распределённых данных" },
];

export default function HomePage() {
  return (
    <div className="flex min-h-[calc(100vh-9rem)] flex-col">
      <section className="relative flex-1 overflow-hidden border-b border-border">
        <div className="pointer-events-none absolute inset-0 pattern-grid-dark [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,#000,transparent)]" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-96 glow-top-primary" />
        <div className="container relative mx-auto flex max-w-4xl flex-col items-center px-4 py-24 text-center sm:py-32">
          <Badge
            variant="outline"
            className="gap-2 border-border bg-background/40 px-3 py-1 text-muted-foreground backdrop-blur"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />
            Децентрализованная сеть активна
          </Badge>
          <h1 className="mt-8 text-4xl font-bold tracking-tight sm:text-6xl">
            Блочный{" "}
            <span className="bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
              Интернет
            </span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground sm:text-xl">
            Собственные домены, каталог децентрализованных сайтов и безопасное
            хранение файлов — без посредников и паролей.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <Link href="/domains" className={buttonVariants({ size: "lg" })}>
              Начать с домена
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
            <Link
              href="/catalog"
              className={buttonVariants({ size: "lg", variant: "outline" })}
            >
              Открыть каталог
            </Link>
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container mx-auto grid max-w-4xl grid-cols-1 divide-y divide-border px-4 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="flex flex-col items-center gap-1 py-6 text-center"
            >
              <span className="text-2xl font-semibold tracking-tight">
                {stat.value}
              </span>
              <span className="text-sm text-muted-foreground">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto max-w-5xl px-4 py-20">
        <div className="mb-10 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">
              Разделы сервиса
            </h2>
            <p className="mt-2 text-muted-foreground">
              Всё необходимое для жизни в децентрализованной сети.
            </p>
          </div>
          <Badge variant="secondary" className="hidden shrink-0 sm:inline-flex">
            <ShieldCheck className="h-3 w-3" />
            Без центральных серверов
          </Badge>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {sections.map((section) => (
            <Link
              key={section.href}
              href={section.href}
              className={`card-hover group flex flex-col gap-4 rounded-xl border border-border bg-card p-6 ${section.hoverBorder}`}
            >
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-lg ring-1 ${section.iconBg} ${section.accent}`}
              >
                <section.icon className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-semibold">{section.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {section.description}
                </p>
              </div>
              <span className="inline-flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors group-hover:text-foreground">
                Открыть раздел
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
