import { ProfilePanel } from "@/components/profile-panel";

export default function ProfilePage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h1 className="text-3xl font-bold tracking-tight">Личный профиль</h1>
        <p className="mt-2 text-muted-foreground">
          Войдите по публичному ключу, чтобы видеть свой адрес и домены.
        </p>
      </div>
      <ProfilePanel />
    </div>
  );
}
