import { FilesManager } from "@/components/files-manager";

export default function StoragePage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h1 className="text-3xl font-bold tracking-tight">Хранилище</h1>
        <p className="mt-2 text-muted-foreground">
          Загружайте файлы в децентрализованное хранилище и делитесь уникальными
          ссылками для скачивания.
        </p>
      </div>
      <FilesManager />
    </div>
  );
}
