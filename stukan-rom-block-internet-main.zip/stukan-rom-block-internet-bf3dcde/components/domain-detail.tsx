"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { Domain } from "@/lib/models";
import {
  ArrowLeft,
  CalendarDays,
  Fingerprint,
  Globe,
  Loader2,
  Trash2,
} from "lucide-react";

const STORAGE_KEY = "blocknet.address";

export function DomainDetail({ domain }: { domain: Domain }) {
  const router = useRouter();
  const [currentAddress, setCurrentAddress] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    setCurrentAddress(window.localStorage.getItem(STORAGE_KEY));
  }, []);

  const handleDelete = useCallback(() => {
    const doDelete = async () => {
      if (!currentAddress) return;
      setIsDeleting(true);
      try {
        const response = await fetch(
          `/api/domains/${encodeURIComponent(domain.name)}?owner=${encodeURIComponent(currentAddress)}`,
          { method: "DELETE" }
        );
        if (response.ok) {
          toast.success(`Домен ${domain.name} удалён`);
          router.push("/domains");
        } else {
          const error = await response.json();
          toast.error(error.error || "Не удалось удалить домен");
        }
      } catch {
        toast.error("Не удалось удалить домен");
      } finally {
        setIsDeleting(false);
      }
    };

    toast(`Удалить домен ${domain.name}?`, {
      action: { label: "Удалить", onClick: doDelete },
      cancel: { label: "Отмена", onClick: () => {} },
    });
  }, [currentAddress, domain.name, router]);

  const isOwner = currentAddress === domain.ownerAddress;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Link
        href="/domains"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        Назад к моим доменам
      </Link>

      <Card className="overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="pb-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-violet-400/10 text-violet-400 ring-1 ring-violet-400/20">
                <Globe className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="font-mono text-xl">
                  {domain.name}
                </CardTitle>
                <CardDescription>
                  Децентрализованный домен в сети
                </CardDescription>
              </div>
            </div>
            <Badge className="gap-1.5 bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />
              Активен
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3 rounded-lg border border-border bg-muted/30 p-4">
              <Fingerprint className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
              <div className="min-w-0">
                <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Владелец
                </p>
                <code className="break-all font-mono text-sm">
                  {domain.ownerAddress}
                </code>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-4">
              <CalendarDays className="h-4 w-4 shrink-0 text-sky-400" />
              <div>
                <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Дата регистрации
                </p>
                <p className="text-sm">
                  {new Date(domain.createdAt).toLocaleDateString("ru-RU", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </p>
              </div>
            </div>
          </div>

          {isOwner ? (
            <Button
              variant="outline"
              className="w-full text-destructive hover:bg-destructive/10 hover:text-destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Удаляем...
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Отменить регистрацию
                </>
              )}
            </Button>
          ) : (
            <div className="flex items-start gap-2 rounded-lg bg-muted/50 px-3 py-2.5 text-xs text-muted-foreground">
              <Fingerprint className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              Этот домен не принадлежит текущему аккаунту — удаление недоступно.
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Link
          href="/domains"
          className={buttonVariants({ variant: "outline" })}
        >
          К списку доменов
        </Link>
      </div>
    </div>
  );
}
