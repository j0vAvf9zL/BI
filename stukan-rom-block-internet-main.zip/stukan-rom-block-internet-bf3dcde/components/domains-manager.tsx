"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import type { Domain } from "@/lib/models";
import { domainNameSchema } from "@/lib/validation";
import {
  ArrowRight,
  ExternalLink,
  Globe,
  KeyRound,
  Loader2,
  Plus,
  Trash2,
} from "lucide-react";

const STORAGE_KEY = "blocknet.address";

type Availability = "idle" | "checking" | "available" | "taken";

export function DomainsManager() {
  const router = useRouter();
  const [address, setAddress] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [domains, setDomains] = useState<Domain[]>([]);
  const [isLoadingDomains, setIsLoadingDomains] = useState(false);
  const [nameInput, setNameInput] = useState("");
  const [nameError, setNameError] = useState<string | null>(null);
  const [availability, setAvailability] = useState<Availability>("idle");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const checkTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadDomains = useCallback(async (owner: string) => {
    setIsLoadingDomains(true);
    try {
      const response = await fetch(
        `/api/domains?owner=${encodeURIComponent(owner)}`
      );
      if (response.ok) {
        setDomains(await response.json());
      } else {
        const error = await response.json();
        setDomains([]);
        toast.error(error.error || "Ошибка загрузки доменов");
      }
    } catch {
      setDomains([]);
      toast.error("Ошибка загрузки доменов");
    } finally {
      setIsLoadingDomains(false);
    }
  }, []);

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setAddress(saved);
      void loadDomains(saved);
    }
    setIsReady(true);
  }, [loadDomains]);

  useEffect(() => {
    if (checkTimer.current) clearTimeout(checkTimer.current);

    const parsed = domainNameSchema.safeParse(nameInput);
    if (!nameInput.trim()) {
      setNameError(null);
      setAvailability("idle");
      return;
    }
    if (!parsed.success) {
      setNameError(parsed.error.issues[0]?.message ?? "Некорректное имя");
      setAvailability("idle");
      return;
    }

    const normalized = parsed.data;
    if (domains.some((domain) => domain.name === normalized)) {
      setNameError(null);
      setAvailability("taken");
      return;
    }

    setNameError(null);
    setAvailability("checking");
    checkTimer.current = setTimeout(() => {
      fetch(`/api/domains/${encodeURIComponent(normalized)}`)
        .then((response) => {
          if (response.status === 404) {
            setAvailability("available");
          } else if (response.status === 200) {
            setAvailability("taken");
          } else {
            setAvailability("idle");
          }
        })
        .catch(() => setAvailability("idle"));
    }, 400);

    return () => {
      if (checkTimer.current) clearTimeout(checkTimer.current);
    };
  }, [nameInput, domains]);

  const handleNameChange = (value: string) => {
    setNameInput(value.trim().toLowerCase());
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address) return;

    const parsed = domainNameSchema.safeParse(nameInput);
    if (!parsed.success) {
      setNameError(parsed.error.issues[0]?.message ?? "Некорректное имя");
      return;
    }

    setIsSubmitting(true);
    const name = parsed.data;
    try {
      const response = await fetch("/api/domains", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, owner: address }),
      });

      if (response.ok) {
        toast.success(`Домен ${name} зарегистрирован`);
        setNameInput("");
        setNameError(null);
        setAvailability("idle");
        await loadDomains(address);
      } else {
        const error = await response.json();
        toast.error(error.error || "Не удалось зарегистрировать домен");
      }
    } catch {
      toast.error("Не удалось зарегистрировать домен");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (domain: Domain) => {
    if (!address) return;

    const doDelete = async () => {
      setDeletingId(domain.id);
      try {
        const response = await fetch(
          `/api/domains/${encodeURIComponent(domain.name)}?owner=${encodeURIComponent(address)}`,
          { method: "DELETE" }
        );
        if (response.ok) {
          toast.success(`Домен ${domain.name} удалён`);
          await loadDomains(address);
        } else {
          const error = await response.json();
          toast.error(error.error || "Не удалось удалить домен");
        }
      } catch {
        toast.error("Не удалось удалить домен");
      } finally {
        setDeletingId(null);
      }
    };

    toast(`Удалить домен ${domain.name}?`, {
      action: { label: "Удалить", onClick: doDelete },
      cancel: { label: "Отмена", onClick: () => {} },
    });
  };

  if (!isReady) {
    return (
      <div className="mx-auto max-w-3xl space-y-3">
        <Skeleton className="h-52 w-full rounded-xl" />
        <Skeleton className="h-40 w-full rounded-xl" />
      </div>
    );
  }

  if (!address) {
    return (
      <Card className="mx-auto max-w-xl overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="items-center pb-4 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20">
            <KeyRound className="h-6 w-6" />
          </div>
          <CardTitle className="mt-2 text-xl">Войдите в профиль</CardTitle>
          <CardDescription>
            Регистрация доменов доступна после входа по публичному ключу.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center pb-6">
          <Link
            href="/profile"
            className={buttonVariants({
              size: "lg",
              className: "w-full sm:w-auto",
            })}
          >
            Перейти ко входу
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </CardContent>
      </Card>
    );
  }

  const availabilityNode = nameError ? (
    <p className="text-sm text-destructive">{nameError}</p>
  ) : availability === "checking" ? (
    <p className="flex items-center gap-2 text-sm text-muted-foreground">
      <Loader2 className="h-3.5 w-3.5 animate-spin" />
      Проверяем доступность...
    </p>
  ) : availability === "available" ? (
    <p className="text-sm text-emerald-400">
      Домен свободен — можно регистрировать
    </p>
  ) : availability === "taken" ? (
    <p className="text-sm text-destructive">
      Домен уже занят, выберите другое имя
    </p>
  ) : null;

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <Card className="overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="pb-2">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-400/10 text-sky-400 ring-1 ring-sky-400/20">
              <Plus className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg">Зарегистрировать домен</CardTitle>
              <CardDescription>
                Имя вида «имя.crypto» — бесплатно и без регистратора
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister} className="space-y-2">
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                value={nameInput}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="мойсайт.crypto"
                disabled={isSubmitting}
                className="h-11 font-mono"
                autoComplete="off"
                spellCheck={false}
                aria-label="Имя домена"
              />
              <Button
                type="submit"
                disabled={isSubmitting || availability === "taken"}
                className="h-11 shrink-0"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Регистрируем...
                  </>
                ) : (
                  <>
                    <Globe className="mr-2 h-4 w-4" />
                    Зарегистрировать
                  </>
                )}
              </Button>
            </div>
            {availabilityNode}
          </form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Мои домены</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Нажмите на домен, чтобы открыть его страницу
            </p>
          </div>
          <Badge variant="outline" className="shrink-0">
            <Globe className="mr-1 h-3.5 w-3.5" />
            {domains.length}
          </Badge>
        </div>

        {isLoadingDomains ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {[0, 1].map((i) => (
              <div
                key={i}
                className="space-y-3 rounded-xl border border-border p-4"
              >
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-24" />
              </div>
            ))}
          </div>
        ) : domains.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                <Globe className="h-7 w-7 text-muted-foreground" />
              </div>
              <p className="font-medium text-muted-foreground">
                Пока нет доменов
              </p>
              <p className="text-sm text-muted-foreground">
                Зарегистрируйте первый домен, чтобы он появился в этом списке.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {domains.map((domain) => (
              <div
                key={domain.id}
                className="card-hover flex items-center gap-3 rounded-xl border border-border bg-card p-4"
              >
                <Link
                  href={`/domains/${encodeURIComponent(domain.name)}`}
                  className="flex min-w-0 flex-1 items-center gap-3"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-violet-400/10 text-violet-400 ring-1 ring-violet-400/20">
                    <Globe className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium group-hover:text-primary">
                      {domain.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Зарегистрирован{" "}
                      {new Date(domain.createdAt).toLocaleDateString("ru-RU")}
                    </p>
                  </div>
                </Link>
                <div className="flex shrink-0 items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Открыть ${domain.name}`}
                    onClick={() =>
                      router.push(`/domains/${encodeURIComponent(domain.name)}`)
                    }
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Удалить ${domain.name}`}
                    disabled={deletingId === domain.id}
                    onClick={() => void handleDelete(domain)}
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
