"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { FileInfo } from "@/lib/models";
import { MAX_FILE_BYTES, uploadFileSchema } from "@/lib/validation";
import {
  ArrowRight,
  CloudUpload,
  Copy,
  Download,
  File,
  FileText,
  HardDrive,
  ImageIcon,
  KeyRound,
  Link2,
  Loader2,
  Music,
  Trash2,
  Upload,
  Video,
  X,
} from "lucide-react";

const STORAGE_KEY = "blocknet.address";

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 Б";
  const units = ["Б", "КБ", "МБ", "ГБ"];
  const index = Math.min(
    Math.floor(Math.log(bytes) / Math.log(1024)),
    units.length - 1
  );
  const value = bytes / 1024 ** index;
  return `${value.toFixed(value >= 100 || index === 0 ? 0 : 1)} ${units[index]}`;
}

function fileIcon(contentType: string) {
  if (contentType.startsWith("image/")) return ImageIcon;
  if (contentType.startsWith("video/")) return Video;
  if (contentType.startsWith("audio/")) return Music;
  if (contentType.startsWith("text/") || contentType === "application/json") {
    return FileText;
  }
  return File;
}

export function FilesManager() {
  const [address, setAddress] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [files, setFiles] = useState<FileInfo[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadFiles = useCallback(async (owner: string) => {
    setIsLoadingFiles(true);
    try {
      const response = await fetch(
        `/api/files?owner=${encodeURIComponent(owner)}`
      );
      if (response.ok) {
        setFiles(await response.json());
      } else {
        const error = await response.json();
        setFiles([]);
        toast.error(error.error || "Ошибка загрузки файлов");
      }
    } catch {
      setFiles([]);
      toast.error("Ошибка загрузки файлов");
    } finally {
      setIsLoadingFiles(false);
    }
  }, []);

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setAddress(saved);
      void loadFiles(saved);
    }
    setIsReady(true);
  }, [loadFiles]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] ?? null;
    if (!file) {
      setSelectedFile(null);
      return;
    }
    const checked = uploadFileSchema.shape.file.safeParse(file);
    if (!checked.success) {
      toast.error(checked.error.issues[0]?.message ?? "Некорректный файл");
      e.target.value = "";
      setSelectedFile(null);
      return;
    }
    setSelectedFile(file);
  };

  const handleClearSelection = () => {
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address || !selectedFile) return;

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("owner", address);
      formData.append("file", selectedFile);

      const response = await fetch("/api/files", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        toast.success("Файл загружен в хранилище");
        handleClearSelection();
        await loadFiles(address);
      } else {
        const error = await response.json();
        toast.error(error.error || "Не удалось загрузить файл");
      }
    } catch {
      toast.error("Не удалось загрузить файл");
    } finally {
      setIsUploading(false);
    }
  };

  const downloadUrl = (file: FileInfo) =>
    `${window.location.origin}/api/files/${encodeURIComponent(file.id)}/download`;

  const handleCopyLink = async (file: FileInfo) => {
    try {
      await navigator.clipboard.writeText(downloadUrl(file));
      toast.success("Ссылка для скачивания скопирована");
    } catch {
      toast.error("Не удалось скопировать ссылку");
    }
  };

  const handleDelete = (file: FileInfo) => {
    if (!address) return;

    const doDelete = async () => {
      setDeletingId(file.id);
      try {
        const response = await fetch(
          `/api/files/${encodeURIComponent(file.id)}?owner=${encodeURIComponent(address)}`,
          { method: "DELETE" }
        );
        if (response.ok) {
          toast.success("Файл удалён из хранилища");
          await loadFiles(address);
        } else {
          const error = await response.json();
          toast.error(error.error || "Не удалось удалить файл");
        }
      } catch {
        toast.error("Не удалось удалить файл");
      } finally {
        setDeletingId(null);
      }
    };

    toast(`Удалить файл ${file.name}?`, {
      action: { label: "Удалить", onClick: doDelete },
      cancel: { label: "Отмена", onClick: () => {} },
    });
  };

  if (!isReady) {
    return (
      <div className="mx-auto max-w-3xl space-y-3">
        <Skeleton className="h-48 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    );
  }

  if (!address) {
    return (
      <Card className="mx-auto max-w-xl overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="items-center pb-4 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20">
            <KeyRound className="h-6 w-6" />
          </div>
          <CardTitle className="mt-2 text-xl">Войдите в профиль</CardTitle>
          <CardDescription>
            Загрузка файлов доступна после входа по публичному ключу.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center pb-6">
          <Link
            href="/profile"
            className={buttonVariants({
              size: "lg",
              className: "w-full sm:w-auto",
            })}
          >
            Перейти ко входу
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <Card className="overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="pb-2">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400 ring-1 ring-amber-400/20">
              <CloudUpload className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg">Загрузить файл</CardTitle>
              <CardDescription>
                Максимальный размер — {MAX_FILE_BYTES / 1024} КБ
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpload} className="space-y-3">
            <label
              htmlFor="file-input"
              className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border bg-muted/20 px-4 py-10 text-center transition-colors hover:border-primary/40 hover:bg-muted/30"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-400/10 text-amber-400 ring-1 ring-amber-400/20">
                <Upload className="h-6 w-6" />
              </div>
              <div>
                <p className="font-medium">Выберите файл</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Файл сохранится в децентрализованном хранилище
                </p>
              </div>
              <input
                id="file-input"
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={handleFileChange}
                disabled={isUploading}
                aria-label="Выбрать файл"
              />
            </label>

            {selectedFile && (
              <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-muted/30 px-3 py-2.5">
                <div className="flex min-w-0 items-center gap-2">
                  <FileText className="h-4 w-4 shrink-0 text-amber-400" />
                  <span className="truncate text-sm font-medium">
                    {selectedFile.name}
                  </span>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {formatBytes(selectedFile.size)}
                  </span>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon-sm"
                    onClick={handleClearSelection}
                    disabled={isUploading}
                    aria-label="Отменить выбор файла"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                  <Button type="submit" size="sm" disabled={isUploading}>
                    {isUploading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="mr-2 h-4 w-4" />
                    )}
                    {isUploading ? "Загружаем..." : "Загрузить"}
                  </Button>
                </div>
              </div>
            )}
          </form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Мои файлы</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              У каждого файла есть уникальная ссылка для скачивания
            </p>
          </div>
          <Badge variant="outline" className="shrink-0">
            <HardDrive className="mr-1 h-3.5 w-3.5" />
            {files.length}
          </Badge>
        </div>

        {isLoadingFiles ? (
          <div className="space-y-3">
            {[0, 1].map((i) => (
              <div
                key={i}
                className="space-y-3 rounded-xl border border-border p-4"
              >
                <Skeleton className="h-4 w-40" />
                <Skeleton className="h-8 w-full" />
              </div>
            ))}
          </div>
        ) : files.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                <HardDrive className="h-7 w-7 text-muted-foreground" />
              </div>
              <p className="font-medium text-muted-foreground">
                Пока нет файлов
              </p>
              <p className="text-sm text-muted-foreground">
                Загрузите первый файл, чтобы получить ссылку для скачивания.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3">
            {files.map((file) => {
              const Icon = fileIcon(file.contentType);
              const url = downloadUrl(file);
              return (
                <div
                  key={file.id}
                  className="card-hover rounded-xl border border-border bg-card p-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-400/10 text-amber-400 ring-1 ring-amber-400/20">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{file.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatBytes(file.size)} ·{" "}
                        {new Date(file.createdAt).toLocaleDateString("ru-RU")}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Скопировать ссылку на ${file.name}`}
                        onClick={() => void handleCopyLink(file)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <a
                        href={url}
                        download
                        aria-label={`Скачать ${file.name}`}
                        className={buttonVariants({
                          variant: "ghost",
                          size: "icon-sm",
                        })}
                      >
                        <Download className="h-4 w-4" />
                      </a>
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Удалить ${file.name}`}
                        disabled={deletingId === file.id}
                        onClick={() => handleDelete(file)}
                        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2">
                    <Link2 className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    <a
                      href={url}
                      download
                      className="truncate font-mono text-xs text-primary hover:underline"
                    >
                      {url}
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
