"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import type { Domain } from "@/lib/models";
import { addressSchema, demoAddress } from "@/lib/validation";
import {
  ArrowRight,
  Copy,
  ExternalLink,
  Fingerprint,
  Globe,
  KeyRound,
  LogOut,
  ShieldCheck,
  Trash2,
} from "lucide-react";

const STORAGE_KEY = "blocknet.address";

export function ProfilePanel() {
  const [address, setAddress] = useState<string | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [domains, setDomains] = useState<Domain[]>([]);
  const [isReady, setIsReady] = useState(false);
  const [isLoadingDomains, setIsLoadingDomains] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadDomains = useCallback(async (owner: string) => {
    setIsLoadingDomains(true);
    try {
      const response = await fetch(
        `/api/domains?owner=${encodeURIComponent(owner)}`
      );
      if (response.ok) {
        setDomains(await response.json());
      } else {
        const error = await response.json();
        setDomains([]);
        toast.error(error.error || "Ошибка загрузки доменов");
      }
    } catch {
      setDomains([]);
      toast.error("Ошибка загрузки доменов");
    } finally {
      setIsLoadingDomains(false);
    }
  }, []);

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setAddress(saved);
      void loadDomains(saved);
    }
    setIsReady(true);
  }, [loadDomains]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = addressSchema.safeParse(inputValue);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Некорректный адрес");
      return;
    }

    setIsSubmitting(true);
    const owner = parsed.data;
    window.localStorage.setItem(STORAGE_KEY, owner);
    setAddress(owner);
    setInputValue("");
    await loadDomains(owner);
    setIsSubmitting(false);
    toast.success("Вы вошли в профиль");
  };

  const handleLogout = () => {
    window.localStorage.removeItem(STORAGE_KEY);
    setAddress(null);
    setDomains([]);
    toast.success("Вы вышли из профиля");
  };

  const handleCopy = async () => {
    if (!address) return;
    try {
      await navigator.clipboard.writeText(address);
      toast.success("Адрес скопирован");
    } catch {
      toast.error("Не удалось скопировать адрес");
    }
  };

  const handleDeleteDomain = (domain: Domain) => {
    if (!address) return;

    const doDelete = async () => {
      setDeletingId(domain.id);
      try {
        const response = await fetch(
          `/api/domains/${encodeURIComponent(domain.name)}?owner=${encodeURIComponent(address)}`,
          { method: "DELETE" }
        );
        if (response.ok) {
          toast.success(`Домен ${domain.name} удалён`);
          await loadDomains(address);
        } else {
          const error = await response.json();
          toast.error(error.error || "Не удалось удалить домен");
        }
      } catch {
        toast.error("Не удалось удалить домен");
      } finally {
        setDeletingId(null);
      }
    };

    toast(`Удалить домен ${domain.name}?`, {
      action: { label: "Удалить", onClick: doDelete },
      cancel: { label: "Отмена", onClick: () => {} },
    });
  };

  if (!isReady) {
    return (
      <div className="mx-auto max-w-xl space-y-3">
        <Skeleton className="h-40 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
      </div>
    );
  }

  if (!address) {
    return (
      <Card className="mx-auto max-w-xl overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="items-center pb-4 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20">
            <KeyRound className="h-6 w-6" />
          </div>
          <CardTitle className="mt-2 text-xl">Вход по ключу</CardTitle>
          <CardDescription>
            Укажите ваш публичный ключ или адрес — без пароля и email.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleLogin} className="space-y-3">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="0x… или публичный ключ"
              disabled={isSubmitting}
              className="h-11 font-mono"
              autoComplete="off"
              spellCheck={false}
              aria-label="Публичный ключ или адрес"
            />
            <Button
              type="submit"
              disabled={isSubmitting}
              className="h-11 w-full"
            >
              <Fingerprint className="mr-2 h-4 w-4" />
              {isSubmitting ? "Входим..." : "Войти в профиль"}
            </Button>
          </form>
          <div className="flex items-center justify-center gap-2 text-sm">
            <span className="text-muted-foreground">Нет ключа?</span>
            <Button
              type="button"
              variant="link"
              className="h-auto px-0 text-primary"
              onClick={() => setInputValue(demoAddress)}
            >
              Использовать демо-адрес
              <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </div>
          <div className="flex items-start gap-2 rounded-lg bg-muted/50 px-3 py-2.5 text-xs text-muted-foreground">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
            Вход имитирует подключение кошелька: пароль и email не нужны, а
            данные остаются в вашем браузере.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <Card className="overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardContent className="space-y-5 pt-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20">
                <Fingerprint className="h-6 w-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-semibold">Личный профиль</p>
                  <Badge className="gap-1.5 bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />
                    В сети
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Вход по публичному ключу
                </p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Выйти
            </Button>
          </div>

          <div className="rounded-lg border border-border bg-muted/30 p-4">
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Ваш адрес
            </p>
            <div className="flex items-center justify-between gap-3">
              <code className="break-all font-mono text-sm">{address}</code>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0"
                onClick={handleCopy}
                aria-label="Скопировать адрес"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Мои домены</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Децентрализованные адреса вида «имя.crypto»
            </p>
          </div>
          <Badge variant="outline" className="shrink-0">
            <Globe className="mr-1 h-3.5 w-3.5" />
            {domains.length}
          </Badge>
        </div>

        {isLoadingDomains ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {[0, 1].map((i) => (
              <div
                key={i}
                className="space-y-3 rounded-xl border border-border p-4"
              >
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-24" />
              </div>
            ))}
          </div>
        ) : domains.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                <Globe className="h-7 w-7 text-muted-foreground" />
              </div>
              <p className="font-medium text-muted-foreground">
                Пока нет доменов
              </p>
              <p className="text-sm text-muted-foreground">
                Зарегистрируйте первый домен, чтобы он появился в этом списке.
              </p>
              <Link
                href="/domains"
                className={buttonVariants({ size: "sm", className: "mt-1" })}
              >
                Зарегистрировать домен
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {domains.map((domain) => (
              <div
                key={domain.id}
                className="card-hover flex items-center gap-3 rounded-xl border border-border bg-card p-4"
              >
                <Link
                  href={`/domains/${encodeURIComponent(domain.name)}`}
                  className="flex min-w-0 flex-1 items-center gap-3"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-violet-400/10 text-violet-400 ring-1 ring-violet-400/20">
                    <Globe className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{domain.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Зарегистрирован{" "}
                      {new Date(domain.createdAt).toLocaleDateString("ru-RU")}
                    </p>
                  </div>
                </Link>
                <div className="flex shrink-0 items-center gap-1">
                  <Link
                    href={`/domains/${encodeURIComponent(domain.name)}`}
                    aria-label={`Открыть ${domain.name}`}
                    className={buttonVariants({
                      variant: "ghost",
                      size: "icon-sm",
                    })}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Link>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Удалить ${domain.name}`}
                    disabled={deletingId === domain.id}
                    onClick={() => handleDeleteDomain(domain)}
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
