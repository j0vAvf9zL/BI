"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import type { Site } from "@/lib/models";
import { ArrowRight, Compass, Search } from "lucide-react";

export function SiteCatalog({ sites }: { sites: Site[] }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return sites;
    return sites.filter(
      (site) =>
        site.name.toLowerCase().includes(normalized) ||
        site.domain.toLowerCase().includes(normalized)
    );
  }, [sites, query]);

  return (
    <div className="space-y-6">
      <div className="relative mx-auto max-w-2xl">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Поиск по названию или домену…"
          className="h-12 pl-10 font-normal"
          aria-label="Поиск по каталогу"
          autoComplete="off"
        />
      </div>

      <p className="text-center text-sm text-muted-foreground">
        Найдено сайтов:{" "}
        <span className="font-medium text-foreground">{filtered.length}</span>
      </p>

      {filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
              <Compass className="h-7 w-7 text-muted-foreground" />
            </div>
            <p className="font-medium text-muted-foreground">
              Ничего не найдено
            </p>
            <p className="text-sm text-muted-foreground">
              Попробуйте изменить запрос или очистить поле поиска.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((site) => (
            <Link
              key={site.id}
              href={`/catalog/${encodeURIComponent(site.domain)}`}
              className="card-hover group flex flex-col gap-4 rounded-xl border border-border bg-card p-5"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-violet-400/10 text-violet-400 ring-1 ring-violet-400/20">
                    <Compass className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="truncate font-semibold">{site.name}</h3>
                    <p className="truncate font-mono text-xs text-muted-foreground">
                      {site.domain}
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
              </div>
              <p className="line-clamp-3 flex-1 text-sm text-muted-foreground">
                {site.description}
              </p>
              <div className="flex items-center justify-between gap-2">
                <Badge variant="secondary">{site.category}</Badge>
                <span
                  className={
                    site.status === "active"
                      ? "flex items-center gap-1.5 text-xs text-emerald-400"
                      : "flex items-center gap-1.5 text-xs text-amber-400"
                  }
                >
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      site.status === "active"
                        ? "bg-emerald-400 pulse-dot"
                        : "bg-amber-400"
                    }`}
                  />
                  {site.status === "active" ? "Активен" : "Обслуживание"}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
