"use client";

import { useCallback } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { Site } from "@/lib/models";
import {
  ArrowLeft,
  CalendarDays,
  Compass,
  Copy,
  Fingerprint,
  Globe,
  Tags,
} from "lucide-react";

export function SiteDetail({ site }: { site: Site }) {
  const handleCopyDomain = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(site.domain);
      toast.success("Адрес сайта скопирован");
    } catch {
      toast.error("Не удалось скопировать адрес");
    }
  }, [site.domain]);

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Link
        href="/catalog"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        Назад к каталогу
      </Link>

      <Card className="overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-sky-400 via-violet-400 to-fuchsia-400" />
        <CardHeader className="pb-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-violet-400/10 text-violet-400 ring-1 ring-violet-400/20">
                <Compass className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-xl">{site.name}</CardTitle>
                <CardDescription>
                  Сайт в децентрализованной сети
                </CardDescription>
              </div>
            </div>
            <Badge
              className={
                site.status === "active"
                  ? "gap-1.5 bg-emerald-400/10 text-emerald-400 ring-1 ring-emerald-400/20"
                  : "gap-1.5 bg-amber-400/10 text-amber-400 ring-1 ring-amber-400/20"
              }
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  site.status === "active"
                    ? "bg-emerald-400 pulse-dot"
                    : "bg-amber-400"
                }`}
              />
              {site.status === "active" ? "Активен" : "Обслуживание"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3 rounded-lg border border-border bg-muted/30 p-4">
              <Globe className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
              <div className="min-w-0 flex-1">
                <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Адрес сайта
                </p>
                <div className="flex items-center justify-between gap-3">
                  <code className="break-all font-mono text-sm">
                    {site.domain}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    onClick={handleCopyDomain}
                    aria-label="Скопировать адрес сайта"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="rounded-lg border border-border bg-muted/30 p-4">
              <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Описание
              </p>
              <p className="text-sm">{site.description}</p>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-4">
                <Tags className="h-4 w-4 shrink-0 text-violet-400" />
                <div>
                  <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Категория
                  </p>
                  <p className="text-sm">{site.category}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-4">
                <CalendarDays className="h-4 w-4 shrink-0 text-sky-400" />
                <div>
                  <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Добавлен в каталог
                  </p>
                  <p className="text-sm">
                    {new Date(site.createdAt).toLocaleDateString("ru-RU", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                    })}
                  </p>
                </div>
              </div>
            </div>

            {site.ownerAddress ? (
              <div className="flex items-start gap-3 rounded-lg border border-border bg-muted/30 p-4">
                <Fingerprint className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                <div className="min-w-0">
                  <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Публикатор
                  </p>
                  <code className="break-all font-mono text-sm">
                    {site.ownerAddress}
                  </code>
                </div>
              </div>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Link
          href="/catalog"
          className={buttonVariants({ variant: "outline" })}
        >
          Ко всем сайтам
        </Link>
      </div>
    </div>
  );
}
