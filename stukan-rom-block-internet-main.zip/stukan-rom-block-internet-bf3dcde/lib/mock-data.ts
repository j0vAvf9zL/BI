// Мок-данные для статического режима (без БД)
// Используются когда USE_DATABASE=false или БД недоступна

import { Domain, Service, Site, StoredFile } from "./models";
import { demoAddress } from "./validation";

export const mockServices: Service[] = [
  {
    id: "mock-service-1",
    name: "API Gateway",
    description: "Шлюз для микросервисной архитектуры",
    status: "active",
    url: "https://api.example.com",
    createdAt: new Date("2024-01-15").toISOString(),
    updatedAt: new Date("2024-01-15").toISOString(),
  },
  {
    id: "mock-service-2",
    name: "Auth Service",
    description: "Сервис аутентификации и авторизации",
    status: "active",
    url: "https://auth.example.com",
    createdAt: new Date("2024-02-01").toISOString(),
    updatedAt: new Date("2024-02-01").toISOString(),
  },
  {
    id: "mock-service-3",
    name: "ML Pipeline",
    description: "Пайплайн для обработки данных с AI",
    status: "deploying",
    url: undefined,
    createdAt: new Date("2024-03-10").toISOString(),
    updatedAt: new Date("2024-03-10").toISOString(),
  },
];

export const mockDomains: Domain[] = [
  {
    id: "mock-domain-1",
    name: "alisa.crypto",
    ownerAddress: demoAddress,
    createdAt: new Date("2024-04-12").toISOString(),
    updatedAt: new Date("2024-04-12").toISOString(),
  },
  {
    id: "mock-domain-2",
    name: "mywallet.crypto",
    ownerAddress: demoAddress,
    createdAt: new Date("2024-06-20").toISOString(),
    updatedAt: new Date("2024-06-20").toISOString(),
  },
  {
    id: "mock-domain-3",
    name: "blocksite.crypto",
    ownerAddress: demoAddress,
    createdAt: new Date("2024-09-02").toISOString(),
    updatedAt: new Date("2024-09-02").toISOString(),
  },
];

export const mockSites: Site[] = [
  {
    id: "alisa.crypto",
    name: "Алиса",
    domain: "alisa.crypto",
    description:
      "Персональный блог об исследованиях, путешествиях и жизни в децентрализованной сети.",
    category: "Блог",
    ownerAddress: demoAddress,
    status: "active",
    createdAt: new Date("2024-04-12").toISOString(),
    updatedAt: new Date("2024-04-12").toISOString(),
  },
  {
    id: "mywallet.crypto",
    name: "Мой Кошелёк",
    domain: "mywallet.crypto",
    description:
      "Простой некастодиальный кошелёк для хранения ключей и подписи транзакций прямо в браузере.",
    category: "Кошелёк",
    ownerAddress: demoAddress,
    status: "active",
    createdAt: new Date("2024-06-20").toISOString(),
    updatedAt: new Date("2024-06-20").toISOString(),
  },
  {
    id: "blocksite.crypto",
    name: "BlockSite",
    domain: "blocksite.crypto",
    description:
      "Платформа для публикации децентрализованных сайтов и приложений без центральных серверов.",
    category: "Платформа",
    ownerAddress: demoAddress,
    status: "active",
    createdAt: new Date("2024-09-02").toISOString(),
    updatedAt: new Date("2024-09-02").toISOString(),
  },
  {
    id: "cryptonews.crypto",
    name: "КриптоНовости",
    domain: "cryptonews.crypto",
    description:
      "Ежедневные новости о децентрализованных технологиях, доменах и web3-сервисах.",
    category: "Новости",
    status: "active",
    createdAt: new Date("2024-03-05").toISOString(),
    updatedAt: new Date("2024-03-05").toISOString(),
  },
  {
    id: "openmarket.crypto",
    name: "Открытый Маркет",
    domain: "openmarket.crypto",
    description:
      "Торговая площадка без посредников: товары и услуги напрямую между участниками сети.",
    category: "Маркетплейс",
    status: "active",
    createdAt: new Date("2024-05-18").toISOString(),
    updatedAt: new Date("2024-05-18").toISOString(),
  },
  {
    id: "medialibrary.crypto",
    name: "Медиатека",
    domain: "medialibrary.crypto",
    description:
      "Распределённая библиотека книг, музыки и видео, доступная из любой точки сети.",
    category: "Медиа",
    status: "maintenance",
    createdAt: new Date("2024-07-30").toISOString(),
    updatedAt: new Date("2024-07-30").toISOString(),
  },
];

export const mockFiles: StoredFile[] = [
  {
    id: "mock-file-1",
    ownerAddress: demoAddress,
    name: "привет-blocknet.txt",
    size: 31,
    contentType: "text/plain",
    data: new TextEncoder().encode("Добро пожаловать в Блочный Интернет"),
    createdAt: new Date("2024-08-14").toISOString(),
    updatedAt: new Date("2024-08-14").toISOString(),
  },
  {
    id: "mock-file-2",
    ownerAddress: demoAddress,
    name: "manifesto.web3.txt",
    size: 64,
    contentType: "text/plain",
    data: new TextEncoder().encode(
      "Файлы принадлежат пользователям, а не центральным серверам."
    ),
    createdAt: new Date("2024-09-21").toISOString(),
    updatedAt: new Date("2024-09-21").toISOString(),
  },
];
