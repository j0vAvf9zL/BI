import { ConditionalCheckFailedException } from "@aws-sdk/client-dynamodb";
import { docClient } from "./db";
import {
  GetCommand,
  PutCommand,
  DeleteCommand,
  QueryCommand,
  ScanCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { TableName, IndexName } from "./schema";

export interface Service {
  id: string;
  name: string;
  description?: string;
  status: "active" | "inactive" | "deploying";
  url?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Domain {
  id: string;
  name: string;
  ownerAddress: string;
  createdAt: string;
  updatedAt: string;
}

export interface Site {
  id: string;
  name: string;
  domain: string;
  description: string;
  category: string;
  ownerAddress?: string;
  status: "active" | "maintenance";
  createdAt: string;
  updatedAt: string;
}

export interface StoredFile {
  id: string;
  ownerAddress: string;
  name: string;
  size: number;
  contentType: string;
  data: Uint8Array;
  createdAt: string;
  updatedAt: string;
}

export type FileInfo = Omit<StoredFile, "data">;

export function toFileInfo(file: StoredFile): FileInfo {
  return {
    id: file.id,
    ownerAddress: file.ownerAddress,
    name: file.name,
    size: file.size,
    contentType: file.contentType,
    createdAt: file.createdAt,
    updatedAt: file.updatedAt,
  };
}

export async function getServiceById(id: string): Promise<Service | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
  return (result.Item as Service) ?? null;
}

export async function getServicesByStatus(status: string): Promise<Service[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.SERVICES,
      IndexName: IndexName.SERVICES_STATUS,
      KeyConditionExpression: "#status = :status",
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ExpressionAttributeValues: {
        ":status": status,
      },
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function getAllServices(): Promise<Service[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.SERVICES,
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function createService(
  data: Omit<Service, "createdAt" | "updatedAt">
): Promise<Service> {
  const now = new Date().toISOString();
  const service: Service = {
    ...data,
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.SERVICES,
      Item: service,
    })
  );

  return service;
}

export async function updateService(
  id: string,
  data: Partial<Pick<Service, "name" | "description" | "status" | "url">>
): Promise<Service> {
  const updateExpr = [];
  const exprValues: Record<string, unknown> = {};
  const exprNames: Record<string, string> = {};

  if (data.name !== undefined) {
    updateExpr.push("#name = :name");
    exprValues[":name"] = data.name;
    exprNames["#name"] = "name";
  }

  if (data.description !== undefined) {
    updateExpr.push("#description = :description");
    exprValues[":description"] = data.description;
    exprNames["#description"] = "description";
  }

  if (data.status !== undefined) {
    updateExpr.push("#status = :status");
    exprValues[":status"] = data.status;
    exprNames["#status"] = "status";
  }

  if (data.url !== undefined) {
    updateExpr.push("#url = :url");
    exprValues[":url"] = data.url;
    exprNames["#url"] = "url";
  }

  updateExpr.push("updatedAt = :updatedAt");
  exprValues[":updatedAt"] = new Date().toISOString();

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.SERVICES,
      Key: { id },
      UpdateExpression: `set ${updateExpr.join(", ")}`,
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames:
        Object.keys(exprNames).length > 0 ? exprNames : undefined,
      ReturnValues: "ALL_NEW",
    })
  );

  return result.Attributes as Service;
}

export async function deleteService(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
}

export async function getDomainsByOwner(
  ownerAddress: string
): Promise<Domain[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.DOMAINS,
      IndexName: IndexName.DOMAINS_OWNER,
      KeyConditionExpression: "ownerAddress = :ownerAddress",
      ExpressionAttributeValues: {
        ":ownerAddress": ownerAddress,
      },
    })
  );
  return (result.Items as Domain[]) ?? [];
}

export class DomainTakenError extends Error {
  readonly domainName: string;

  constructor(domainName: string) {
    super(`Домен ${domainName} уже занят`);
    this.name = "DomainTakenError";
    this.domainName = domainName;
  }
}

export async function getDomainByName(name: string): Promise<Domain | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.DOMAINS,
      Key: { id: name },
    })
  );
  return (result.Item as Domain) ?? null;
}

export async function registerDomain(
  name: string,
  ownerAddress: string
): Promise<Domain> {
  const now = new Date().toISOString();
  const domain: Domain = {
    id: name,
    name,
    ownerAddress,
    createdAt: now,
    updatedAt: now,
  };

  try {
    await docClient.send(
      new PutCommand({
        TableName: TableName.DOMAINS,
        Item: domain,
        ConditionExpression: "attribute_not_exists(id)",
      })
    );
  } catch (error) {
    if (error instanceof ConditionalCheckFailedException) {
      throw new DomainTakenError(name);
    }
    throw error;
  }

  return domain;
}

export async function deleteDomain(
  id: string,
  ownerAddress: string
): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.DOMAINS,
      Key: { id },
      ConditionExpression: "ownerAddress = :ownerAddress",
      ExpressionAttributeValues: {
        ":ownerAddress": ownerAddress,
      },
    })
  );
}

export async function getAllSites(): Promise<Site[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.SITES,
    })
  );
  return (result.Items as Site[]) ?? [];
}

export async function getSiteByDomain(domain: string): Promise<Site | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.SITES,
      Key: { id: domain },
    })
  );
  return (result.Item as Site) ?? null;
}

export async function getFilesByOwner(
  ownerAddress: string
): Promise<StoredFile[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.FILES,
      IndexName: IndexName.FILES_OWNER,
      KeyConditionExpression: "ownerAddress = :ownerAddress",
      ExpressionAttributeValues: {
        ":ownerAddress": ownerAddress,
      },
    })
  );
  return (result.Items as StoredFile[]) ?? [];
}

export async function getFileById(id: string): Promise<StoredFile | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.FILES,
      Key: { id },
    })
  );
  return (result.Item as StoredFile) ?? null;
}

export async function saveFile(
  data: Omit<StoredFile, "createdAt" | "updatedAt">
): Promise<StoredFile> {
  const now = new Date().toISOString();
  const file: StoredFile = {
    ...data,
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.FILES,
      Item: file,
    })
  );

  return file;
}

export async function deleteFile(
  id: string,
  ownerAddress: string
): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.FILES,
      Key: { id },
      ConditionExpression: "ownerAddress = :ownerAddress",
      ExpressionAttributeValues: {
        ":ownerAddress": ownerAddress,
      },
    })
  );
}
