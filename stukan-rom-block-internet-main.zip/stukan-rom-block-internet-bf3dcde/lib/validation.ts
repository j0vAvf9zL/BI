import { z } from "zod";

export const demoAddress = "0x7f29c1d0a3b8e4f695c2d3a0b1c4e5f6879a2b3c4";

export const addressSchema = z
  .string()
  .trim()
  .min(8, "Адрес слишком короткий")
  .max(130, "Адрес слишком длинный")
  .regex(
    /^(0x[a-fA-F0-9]{6,}|[A-Za-z0-9_-]{8,128})$/,
    "Укажите корректный публичный ключ или адрес"
  );

export const ownerQuerySchema = z.object({
  owner: addressSchema,
});

export const domainNameSchema = z
  .string()
  .trim()
  .toLowerCase()
  .max(70, "Имя слишком длинное")
  .regex(
    /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.crypto$/,
    "Имя должно быть вида «имя.crypto»: латиница, цифры и дефис"
  );

export const registerDomainSchema = z.object({
  name: domainNameSchema,
  owner: addressSchema,
});

export const deleteDomainQuerySchema = z.object({
  owner: addressSchema,
});

export const MAX_FILE_BYTES = 350 * 1024;

export const uploadFileSchema = z.object({
  owner: addressSchema,
  file: z
    .instanceof(File)
    .refine((file) => file.size > 0, "Файл пустой")
    .refine(
      (file) => file.size <= MAX_FILE_BYTES,
      `Файл слишком большой: максимум ${MAX_FILE_BYTES / 1024} КБ`
    ),
});
